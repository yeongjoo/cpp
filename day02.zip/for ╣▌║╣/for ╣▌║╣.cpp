﻿#include "pch.h"
#include <iostream>
using namespace std;
int main()
{
	//시작값, 끝값
	for (int i = 0; i < 10; i++)
	{
		cout << i << ": ★" << endl;
	}
}
