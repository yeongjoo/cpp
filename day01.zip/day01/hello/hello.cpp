﻿#include "pch.h"
#include <iostream>
using namespace std;	//std 사용하지 않기위해 위에서 언급
//주석
//실행 -> ctrl+F5 
//기본적으로 모니터(console)에 출력!! 키보드에 입력

int main()
{
    cout << "Hello World!\n";	//console 방향으로(<<) output
	cout << "안녕하세요..\n";
	cout << "이영주입니다..\n";	//한줄 복사 -> ctrl+d
	cout << "c++프로그래밍입니다.." << endl;	//pipe연산자 -> line의 끝
}
