﻿//한줄삭제 ctrl+l

#include "pch.h"
#include <iostream>

using namespace std; //na쓰고 ctrl+spacebar

int main()
{
    cout << "Hello World!\n"; 
}

